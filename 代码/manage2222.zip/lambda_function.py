import json
import requests

def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        urls = body.get('url', [])
        tags = body.get('tags', [])
        action_type = body.get('type', None)

        if action_type is None:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid request: type is required')
            }

        # 调用外部API获取数据
        external_api_url = 'https://hc2ynd7hpb.execute-api.us-east-1.amazonaws.com/dev/5225toDB'
        response = requests.get(external_api_url)
        
        if response.status_code != 200:
            return {
                'statusCode': response.status_code,
                'body': json.dumps('Failed to fetch data from external API')
            }
        
        data = response.json()
        
        # 创建一个URL到标签的字典
        existing_data = {item['URL']: item['Tags'] for item in data if 'URL' in item and 'Tags' in item}

        if action_type == 1:
            # 添加标签
            for url in urls:
                if url in existing_data:
                    existing_tags = set(existing_data[url])
                    new_tags = existing_tags.union(set(tags))
                    existing_data[url] = list(new_tags)
                else:
                    existing_data[url] = tags
            return {
                'statusCode': 200,
                'body': json.dumps('Tags added successfully')
            }
        elif action_type == 0:
            # 删除标签
            for url in urls:
                if url in existing_data:
                    existing_tags = set(existing_data[url])
                    new_tags = existing_tags.difference(set(tags))
                    existing_data[url] = list(new_tags)
            return {
                'statusCode': 200,
                'body': json.dumps('Tags removed successfully')
            }
        else:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid type')
            }
    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps(f'Missing parameter: {str(e)}')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Internal server error: {str(e)}')
        }
