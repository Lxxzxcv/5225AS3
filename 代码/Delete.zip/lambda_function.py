import json
import boto3
import requests

def lambda_handler(event, context):
    try:
        # 直接解析传入的事件
        body = event.get('body')
        if body:
            body = json.loads(body)
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Request body is required'}),
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type'
                }
            }

        urls = body.get('url', [])

        if not urls:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'URL list is required'}),
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type'
                }
            }

        # 调用外部API来删除S3对象
        external_api_url = 'https://hc2ynd7hpb.execute-api.us-east-1.amazonaws.com/dev/5225toDB'
        headers = {
            'Content-Type': 'application/json'
        }
        payload = {
            'url': urls
        }

        response = requests.post(external_api_url, headers=headers, json=payload)

        if response.status_code == 200:
            return {
                'statusCode': 200,
                'body': json.dumps('Images and thumbnails deleted successfully'),
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type'
                }
            }
        else:
            return {
                'statusCode': response.status_code,
                'body': response.text,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type'
                }
            }
    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps(f'Missing parameter: {str(e)}'),
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            }
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Internal server error: {str(e)}'),
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            }
        }
