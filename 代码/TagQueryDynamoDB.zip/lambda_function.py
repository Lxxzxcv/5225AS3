import json
import boto3
from boto3.dynamodb.conditions import Attr

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('ImageTagsTable')  # 修改为您的表名

    # 获取查询参数
    tags = event['queryStringParameters']['tags'].split(',')

    # 创建FilterExpression
    filter_expression = Attr('Tags').contains(tags[0])
    for tag in tags[1:]:
        filter_expression = filter_expression & Attr('Tags').contains(tag)

    response = table.scan(
        FilterExpression=filter_expression
    )

    # 将集合类型转换为列表类型
    items = response['Items']
    for item in items:
        if 'Tags' in item:
            item['Tags'] = list(item['Tags'])

    return {
        'statusCode': 200,
        'body': json.dumps(items)
    }
