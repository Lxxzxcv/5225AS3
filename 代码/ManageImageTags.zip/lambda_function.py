import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ImageTagsTable')  # 修改为您的表名

def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        urls = body.get('url', [])
        tags = body.get('tags', [])
        action_type = body.get('type', None)
        
        if action_type is None:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid request: type is required')
            }

        if action_type == 1:
            for url in urls:
                table.update_item(
                    Key={'URL': url},
                    UpdateExpression='ADD Tags :tags',
                    ExpressionAttributeValues={':tags': set(tags)}
                )
            return {
                'statusCode': 200,
                'body': json.dumps('Tags added successfully')
            }
        elif action_type == 0:
            for url in urls:
                table.update_item(
                    Key={'URL': url},
                    UpdateExpression='DELETE Tags :tags',
                    ExpressionAttributeValues={':tags': set(tags)}
                )
            return {
                'statusCode': 200,
                'body': json.dumps('Tags removed successfully')
            }
        else:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid type')
            }
    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps(f'Missing parameter: {str(e)}')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Internal server error: {str(e)}')
        }
